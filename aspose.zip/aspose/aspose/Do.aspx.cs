﻿using Aspose.Words;
using Aspose.Words.Drawing;
using Aspose.Words.Reporting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aspose
{
    public partial class Do : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string tempPath = Server.MapPath("~/Temp/Template-16.doc");
            var doc = new Document(tempPath); //载入模板
            List<string> images = new List<string>();
            DirectoryInfo root = new DirectoryInfo(Server.MapPath("~/Digital"));
            foreach (FileInfo f in root.GetFiles())
            {
                images.Add(f.FullName);
            }

            for (int i = 1; i < 60; i++)
            {
                doc.Range.Replace($"«Number{i}»", Path.GetFileNameWithoutExtension(images[i - 1]), false, false);
                doc.Range.Replace(new Regex($"Photo{i}&"), new ReplaceAndInsertImage(images[i - 1]), false);
            }

            doc.Save(this.Response, "16计本1班(照片采集)-已完成" + ".doc", Aspose.Words.ContentDisposition.Attachment,
            Aspose.Words.Saving.SaveOptions.CreateSaveOptions(Aspose.Words.SaveFormat.Doc));
        }

        public class ReplaceAndInsertImage : IReplacingCallback
        {
            /// <summary>
            /// 需要插入的图片路径
            /// </summary>
            public string url { get; set; }

            public ReplaceAndInsertImage(string url)
            {
                this.url = url;
            }

            public ReplaceAction Replacing(ReplacingArgs e)
            {
                //获取当前节点
                var node = e.MatchNode;
                //获取当前文档
                Document doc = node.Document as Document;
                DocumentBuilder builder = new DocumentBuilder(doc);
                //将光标移动到指定节点
                builder.MoveTo(node);
                //插入图片
                //builder.InsertImage(url);

                System.Drawing.Image img = System.Drawing.Image.FromFile(url);
                Shape shape = builder.InsertImage(img);
                // 设置x,y坐标和高宽.
                shape.Left = 0;
                shape.Top = 20;
                shape.Width = 60 * 1.2;
                shape.Height = 80 * 1.2;

                return ReplaceAction.Replace;
            }
        }
    }
}