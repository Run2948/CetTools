﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Aspose.Words;
using Aspose.Words.Drawing;
using Aspose.Words.Reporting;
using Aspose.Words.Saving;
using System.IO;
using System.Data;


namespace aspose
{
    public partial class _Default : System.Web.UI.Page
    {
        public DataTable CreateUserTable()
        {
            DataTable table = new DataTable("UserList");
            table.Columns.Add(new DataColumn("Id", typeof(int)));
            table.Columns.Add("UserName");
            table.Columns.Add("Gender");
            table.Columns.Add("BirthDay");
            table.Columns.Add("Address");
            return table;
        }

        public DataTable CreateScoreTable()
        {
            DataTable table = new DataTable("ScoreList");
            table.Columns.Add(new DataColumn("UserId", typeof(int)));
            table.Columns.Add("Name");
            table.Columns.Add("Score");
            return table;
        }

        public DataTable GetUserDataTable()
        {
            var table = CreateUserTable();
            var user1 = table.NewRow();
            user1["Id"] = 1;
            user1["UserName"] = "张三";
            user1["Gender"] = "男";
            user1["BirthDay"] = "1988-09-02";
            user1["Address"] = "陕西咸阳";
            table.Rows.Add(user1);
            var user2 = table.NewRow();
            user2["Id"] = 2;
            user2["UserName"] = "李四";
            user2["Gender"] = "男";
            user2["BirthDay"] = "1988-09-02";
            user2["Address"] = "陕西西安";
            table.Rows.Add(user2);
            var user3 = table.NewRow();
            user3["Id"] = 3;
            user3["UserName"] = "王五";
            user3["Gender"] = "男";
            user3["BirthDay"] = "1988-09-02";
            user3["Address"] = "陕西宝鸡";
            table.Rows.Add(user3);
            return table;
        }

        public DataTable GetUserScoreDataTable()
        {
            var table = CreateScoreTable();
            var userscore1 = table.NewRow();
            userscore1["UserId"] = 1;
            userscore1["Name"] = "语文";
            userscore1["Score"] = "80";
            table.Rows.Add(userscore1);
            var userscore2 = table.NewRow();
            userscore2["UserId"] = 1;
            userscore2["Name"] = "数学";
            userscore2["Score"] = "69";
            table.Rows.Add(userscore2);
            var user2score1 = table.NewRow();
            user2score1["UserId"] = 2;
            user2score1["Name"] = "语文";
            user2score1["Score"] = "85";
            table.Rows.Add(user2score1);
            var user2score2 = table.NewRow();
            user2score2["UserId"] = 2;
            user2score2["Name"] = "数学";
            user2score2["Score"] = "89";
            table.Rows.Add(user2score2);
            var user3score1 = table.NewRow();
            user3score1["UserId"] = 3;
            user3score1["Name"] = "语文";
            user3score1["Score"] = "70";
            table.Rows.Add(user3score1);
            var user3score2 = table.NewRow();
            user3score2["UserId"] = 3;
            user3score2["Name"] = "数学";
            user3score2["Score"] = "79";
            table.Rows.Add(user3score2);
            return table;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string tempPath = Server.MapPath("~/Temp/Template.doc");
            string logoPath = Server.MapPath("~/Temp/logo.jpg");
            var doc = new Document(tempPath); //载入模板
            //提供数据源
            String[] fieldNames = new String[] { "UserName", "Gender", "BirthDay", "Address", "Logo" };
            Object[] fieldValues = new Object[] { "张三", "男", "1988-09-02", "陕西咸阳", logoPath, logoPath };
            //增加处理图片大小程序
            doc.MailMerge.FieldMergingCallback = new HandleMergeFieldInsertDocument2();
            //合并模版，相当于页面的渲染
            doc.MailMerge.Execute(fieldNames, fieldValues);


            //DataSet dataSet = new DataSet();
            //var userTable = GetUserDataTable();
            //var userScoreTable = GetUserScoreDataTable();
            //dataSet.Tables.Add(userTable);
            //dataSet.Tables.Add(userScoreTable);
            //dataSet.Relations.Add(new DataRelation("ScoreListForUser", userTable.Columns["Id"], userScoreTable.Columns["UserId"]));
            ////合并模版，相当于页面的渲染
            //doc.MailMerge.ExecuteWithRegions(dataSet);


            //在MVC中采用,保存文档到流中，使用base.File输出该文件
            //  var docStream = new MemoryStream();
            //doc.Save(docStream, SaveOptions.CreateSaveOptions(SaveFormat.Doc));
            doc.Save(this.Response, "test" + ".doc", Aspose.Words.ContentDisposition.Attachment,
                  Aspose.Words.Saving.SaveOptions.CreateSaveOptions(Aspose.Words.SaveFormat.Doc));
            //  return base.File(docStream.ToArray(), "application/msword", "Template.doc");
        }


        /*这个是我修改的 插入word 图片的方法*/
        class HandleMergeFieldInsertDocument2 : IFieldMergingCallback
        {
            /// <summary>
            /// This is called for each merge field in the document
            /// when Document.MailMerge.ExecuteWithRegions is called.
            /// </summary>
            /// 
            //文本处理在这里，如果写在这一块，则不起作用
            void IFieldMergingCallback.FieldMerging(FieldMergingArgs e)
            {


                if (e.DocumentFieldName.Equals("UserName"))//如果是Pic字段则处理图片
                {
                    // DocumentBuilder builder = new DocumentBuilder(e.Document);
                    // builder.MoveToMergeField(e.FieldName);
                    // builder.Write("abc");

                    DocumentBuilder builder = new DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.FieldName);
                    builder.Write("这里是我追加的" + e.FieldValue.ToString());

                }
            }
            //图片处理在这里

            void IFieldMergingCallback.ImageFieldMerging(ImageFieldMergingArgs args)
            {             
                 if (args.DocumentFieldName.Equals("Logo2"))//如果是Pic字段则处理图片
                 {
                     // 使用DocumentBuilder处理图片的大小
                     DocumentBuilder builder = new DocumentBuilder(args.Document);
                     builder.MoveToMergeField(args.FieldName);
                     /// Image img = ImageHelper.ImageFromBytes((byte[])args.FieldValue);
                     //  img = ImageHelper.ResizeImageToAFixedSize(img, 200, 25, ImageHelper.ScaleMode.MaxHW);
                     //  Image img = System.Drawing.Image.FromFile(args.FieldValue.ToString());
                     Shape shape = builder.InsertImage(args.FieldValue.ToString());

                     // 设置x,y坐标和高宽.
                     shape.Left = 0;
                     shape.Top = 0;
                     shape.Width = 60;
                     shape.Height = 80;
                 }

                 if (args.DocumentFieldName.Equals("Logo"))//如果是Pic字段则处理图片
                 {
                     // 使用DocumentBuilder处理图片的大小
                     DocumentBuilder builder = new DocumentBuilder(args.Document);
                     builder.MoveToMergeField(args.FieldName);
                     /// Image img = ImageHelper.ImageFromBytes((byte[])args.FieldValue);
                     //  img = ImageHelper.ResizeImageToAFixedSize(img, 200, 25, ImageHelper.ScaleMode.MaxHW);
                     //  Image img = System.Drawing.Image.FromFile(args.FieldValue.ToString());
                     string filePath = args.FieldValue as string;
                     System.Drawing.Image img = System.Drawing.Image.FromFile("c:\\a1.jpg");
                     Shape shape = builder.InsertImage(img);
                     // 设置x,y坐标和高宽.
                     shape.Left = 0;
                     shape.Top = 0;
                     shape.Width = 60;
                     shape.Height = 80;
                 }
                 
            }
        }


        /*这个是例子自带的 写的方法*/
        class HandleMergeFieldInsertDocument : IFieldMergingCallback
        {
            /// <summary>
            /// This is called for each merge field in the document
            /// when Document.MailMerge.ExecuteWithRegions is called.
            /// </summary>
            void IFieldMergingCallback.FieldMerging(FieldMergingArgs e)
            {

            }

            void IFieldMergingCallback.ImageFieldMerging(ImageFieldMergingArgs args)
            {


                if (args.DocumentFieldName.Equals("Logo"))
                {
                    // 使用DocumentBuilder处理图片的大小
                    DocumentBuilder builder = new DocumentBuilder(args.Document);
                    builder.MoveToMergeField(args.FieldName);

                    Shape shape = builder.InsertImage(args.FieldValue.ToString());

                    // 设置x,y坐标和高宽.
                    shape.Left = 0;
                    shape.Top = 0;
                    shape.Width = 60;
                    shape.Height = 80;
                }
            }
        }

    }
}